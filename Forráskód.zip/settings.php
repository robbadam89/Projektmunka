<?php
if(logged()){
?>
<div id="center">
	<a href="./"><div id="logo"></div></a>
	<div class="box">
		<h1>Beállítások</h1>
		<form action="userAuth.php?new-password" method="POST">
			<label for="password">Új jelszó</label>
			<input class="input" type="password" name="new-password" id="newPassword" placeholder="Új jelszó">
			<input class="input" type="password" name="new-password2" id="newPassword2" placeholder="Új jelszó mégegyszer">
			<input class="primary-button" type="submit" value="Új jelszó mentése">
		</form>
	</div>
</div>
<?php
} else {
    echo '<strong>Hát te meg mit akarsz itt?</strong>';
}
?>