<?php
include_once 'config.php';

if(logged()){
    if (isset($_GET["delete"])) {
        $stmt = $mysqli->prepare("UPDATE words_hu SET deleted = 1 WHERE id = ?");
        $stmt->bind_param("i", $_GET["delete"]);
        if ($stmt->execute()) {
            $_SESSION['msg']  = '(' . htmlspecialchars($word, ENT_QUOTES, 'UTF-8') . ') sikeresen törölve az adatbázisból.';
        } else {
            $_SESSION['msg'] = "SQL hiba: " . $mysqli->error;
        }
        $stmt->close();
    } elseif (isset($_POST["word"])) {
        $word = strtolower(trim($_POST["word"]));
        $valid_types = ["r", "m", "k"];
        $type = in_array($_POST["type"], $valid_types) ? $_POST["type"] : $valid_types[array_rand($valid_types)];
        $point = filter_var($_POST["point"], FILTER_VALIDATE_INT, ["options" => ["min_range" => 2, "max_range" => 6]]);
        $point = $point !== false ? $point : mt_rand(2, 6);

        if ($word !== '') {
            $stmt = $mysqli->prepare("SELECT * FROM words_hu WHERE word = ?");
            $stmt->bind_param("s", $word);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows == 0) {
                $stmt = $mysqli->prepare("INSERT INTO words_hu (word, type, point) VALUES (?, ?, ?)");
                $stmt->bind_param("ssi", $word, $type, $point);
                if ($stmt->execute()) {
                    $_SESSION['msg'] = '\'' . htmlspecialchars($word, ENT_QUOTES, 'UTF-8') . '\'' . $lng['added'];
                } else {
                    $_SESSION['msg'] = "SQL hiba: " . $mysqli->error;
                }
                $stmt->close();
            } else {
                $_SESSION['msg'] = 'Ez a szó (' . htmlspecialchars($word, ENT_QUOTES, 'UTF-8') . ') már szerepel az adatbázisban.';
            }
        } else {
            $_SESSION['msg'] = 'Hát a szó hol marad?';
        }
        header("Location: ./?p=addword");
    }
    ?>
    <div id="center">
        <a href="./"><div id="logo"></div></a>
        <div class="box">
        <form action="?p=addword" method="POST">
            <label for="type">Feladvány</label>
            <input class="input" type="text" placeholder="<?php echo htmlspecialchars($lng['word'], ENT_QUOTES, 'UTF-8'); ?>" name="word" id="new-word"/>
            <label for="type">Feladvány típusa</label>
            <select class="input" name="type" id="type">
                <option value="0"><?php echo htmlspecialchars($lng['random'], ENT_QUOTES, 'UTF-8'); ?></option>
                <option value="r"><?php echo htmlspecialchars($lng['draw'], ENT_QUOTES, 'UTF-8'); ?></option>
                <option value="k"><?php echo htmlspecialchars($lng['speak'], ENT_QUOTES, 'UTF-8'); ?></option>
                <option value="m"><?php echo htmlspecialchars($lng['pantomime'], ENT_QUOTES, 'UTF-8'); ?></option>
            </select><br />
            <label for="type">Feladvány nehézsége</label>
            <select class="input" name="point" id="point">
                <option value=""><?php echo htmlspecialchars($lng['random'], ENT_QUOTES, 'UTF-8'); ?></option>
                <option value="2">2 - meh</option>
                <option value="3">3 - <?php echo htmlspecialchars($lng['easy'], ENT_QUOTES, 'UTF-8'); ?></option>
                <option value="4">4 - <?php echo htmlspecialchars($lng['medium'], ENT_QUOTES, 'UTF-8'); ?></option>
                <option value="5">5 - <?php echo htmlspecialchars($lng['hard'], ENT_QUOTES, 'UTF-8'); ?></option>
                <option value="6">6 - <?php echo htmlspecialchars($lng['6pointer'], ENT_QUOTES, 'UTF-8'); ?></option>
            </select><br /><br />
            <input class="primary-button" type="submit" value="<?php echo htmlspecialchars($lng['add'], ENT_QUOTES, 'UTF-8'); ?>" />
        </form>
        <a class="secondary-button" href="./"><?php echo htmlspecialchars($lng['back'], ENT_QUOTES, 'UTF-8'); ?></a>
        </div>
    </div>
<?php
} else {
    echo 'Hát te meg mit akarsz itt?';
}
?>