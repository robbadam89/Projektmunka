<div id="timesup">
	<?php echo $lng['timesup']?>
</div>
<div id="start">
	<div id="center">
		<a href="./"><div id="logo"></div></a>
			<span><?php echo $lng['choose_team']?></span>
		<div id="availableFigures">
			<div color="red" class="figure red choose"></div>
			<div color="blue" class="figure blue choose"></div>
			<div color="yellow" class="figure yellow choose"></div>
			<div color="green" class="figure green choose"></div>
		</div>
		<div id="reservedFigures"></div>
		
		<input id="startBut" type="button" value="<?php echo $lng['start_game'];?>" onclick="start()"/><br />
		<a href="?p=rules">Szabályok</a><br>
	</div>
</div>
<div id="gameboard">
	<div id="main">
		<span id="time">&nbsp;</span>
		<table id="gameboardTable">
			<tr class="mobile">
				<td id="mobile-teams">
					<div id="mobile-teams-box">
						
					</div>
				</td>
			</tr>
			<tr class="no-mobile">
				<td id="cell-4" class="cell btlr"></td>
				<td id="cell-5" class="cell btrr"></td>
				<td id="cell-12" class="cell btlr"></td>
				<td id="cell-13" class="cell btrr"></td>
				<td id="cell-20" class="cell btlr"></td>
				<td id="cell-21" class="cell btrr"></td>
				<td id="cell-28" class="cell btlr"></td>
				<td id="cell-29" class="cell btrr"></td>
				<td id="cell-36" class="cell btlr"></td>
				<td id="cell-37" class="cell btrr"></td>
				<td id="cell-44" class="cell btlr"></td>
				<td id="cell-45" class="cell btrr"></td>
			</tr>
			<tr class="no-mobile">
				<td id="cell-3" class="cell"></td>
				<td id="cell-6" class="cell"></td>
				<td id="cell-11" class="cell"></td>
				<td id="cell-14" class="cell"></td>
				<td id="cell-19" class="cell"></td>
				<td id="cell-22" class="cell"></td>
				<td id="cell-27" class="cell"></td>
				<td id="cell-30" class="cell"></td>
				<td id="cell-35" class="cell"></td>
				<td id="cell-38" class="cell"></td>
				<td id="cell-43" class="cell"></td>
				<td id="cell-46" class="cell"></td>
			</tr>
			<tr class="no-mobile">
				<td id="cell-2" class="cell"></td>
				<td id="cell-7" class="cell"></td>
				<td id="cell-10" class="cell"></td>
				<td id="cell-15" class="cell"></td>
				<td id="cell-18" class="cell"></td>
				<td id="cell-23" class="cell"></td>
				<td id="cell-26" class="cell"></td>
				<td id="cell-31" class="cell"></td>
				<td id="cell-34" class="cell"></td>
				<td id="cell-39" class="cell"></td>
				<td id="cell-42" class="cell"></td>
				<td id="cell-47" class="cell"></td>
			</tr>
			<tr class="no-mobile">
				<td id="cell-1" class="cell"></td>
				<td id="cell-8" class="cell bblr"></td>
				<td id="cell-9" class="cell bbrr"></td>
				<td id="cell-16" class="cell bblr"></td>
				<td id="cell-17" class="cell bbrr"></td>
				<td id="cell-24" class="cell bblr"></td>
				<td id="cell-25" class="cell bbrr"></td>
				<td id="cell-32" class="cell bblr"></td>
				<td id="cell-33" class="cell bbrr"></td>
				<td id="cell-40" class="cell bblr"></td>
				<td id="cell-41" class="cell bbrr"></td>
				<td id="cell-48" class="cell"></td>
			</tr>
			<tr>
				<td id="cell-0" class="cell endcell no-mobile">
				</td>
				<td id="cell" colspan="10" style="" class="">
					<div id="gameControl" class="control">
						<input id="new-crd-btn" class="control-button" type="button" value="<?php echo $lng['new_card'];?>" onclick="getWord()"/>
						<div id="card">
							<span id="word"><?php echo $lng['word'];?>...</span>
							<div id="cardLayer"></div>
						</div>
						<input class="control-button" id="showBut" type="button" value="<?php echo $lng['show_hide'];?>"/>
						<input style="display: none;" class="control-button" id="goBut" type="button" value="<?php echo $lng['go'];?>!"/>
					</div>
					<div id="playerControl" class="control" style="display: none;">
						<div id="plyCntButBox">
							
						</div>
					</div>
				</td>
				<td id="cell-49" class="cell finish endcell no-mobile"></td>
			</tr>
		</table>
	</div>
</div>
<script type="text/javascript">
$(document).ready(function () {
	curTeam = 0;
	point = 0;
	lang = '<?php echo $lang; ?>';
	teams = new Array();
	teamspos = new Array();
	ids = 0;
		$('#timesup').click(function(){$(this).hide();});
		$('.choose').click(function () {
			th = $(this);
			if(jQuery.inArray(th.attr('color'),teams) == -1) {
				$('#reservedFigures').append(th);
				teams.push(th.attr('color'));
				teamspos.push(0);
				th.removeClass('choose');
			}
		});
		for(i=0; i<49; ++i) {
			if(i <= 8 || (i>=25 && i<= 32)) {
				type = 'r';
			}
			else if((i>=9 && i<= 16) || (i>=33 && i<= 40)) {
				type = 'k';
			}
			else if((i>=17 && i<= 24) || (i>=41 && i<= 48)) {
				type = 'm';
			}
			$('#cell-'+i).addClass(type);
		}

		$('#showBut').mousedown(function() {
			$('#cardLayer').hide();
			console.log('Szót mutat!');
		}).mouseup(function() {
			$('#cardLayer').show();
			console.log('Szót rejt!');
		});

		$('#showBut').on({ 'touchstart' : function(){ 
			$('#cardLayer').hide();
			console.log('Szót mutat!');
		} });

		$('#showBut').on({ 'touchend' : function(){ 
			$('#cardLayer').show();
			console.log('Szót rejt!');
		} });
		$('#goBut').on('mouseup', function(){
			fix = true;
			$('#gameControl').hide();
			time = 60;
			timer = setInterval( function() {
				time--;
				min = Math.floor(time/60);
				sec = time-(min*60);
				sec = sec < 10 ? '0'+sec : sec;
				$('#time').html(min+':'+sec);
				if(time == 0) {
					$('#timesup').show().append("<embed src=\"timeup.mp3\" hidden=\"true\" autostart=\"true\" loop=\"false\" />");
					clearInterval(timer);
					}
				}
			,1000);
			if(point == 6) {
				t = '';
				for(f=0; f<teams.length; f++) {
					t += '<div teamid="'+f+'" class="plyCntBut '+teams[f]+'-c">'+point+'</div>';
				}
			}
			else { t = '<div teamid="'+curTeam+'" class="plyCntBut '+teams[curTeam]+'-c">'+point+'</div>';}
			t += '<div teamid="no" class="plyCntBut fail">Bukta</div>';
			console.log('Rajta!');
			$('#plyCntButBox').html(t);
			$('#playerControl').show().ready(function() {
				$('.plyCntBut').click(function(){
					if(fix) {
						clearInterval(timer);
						$('#time').html('&nbsp;');
						tid = $(this).attr('teamid');
						if(tid == 'no') {
							console.log('Senki sem nyert.');
							tid = curTeam;
						} else {
							console.log('Nyertes kör.');
							move(tid);
						}
						$('#playerControl').hide();
						$('#goBut').hide();
						$('#gameControl').show();
						round();
						fix = false;
					}
				});
			});
		});
	});
	function move(id) {
		console.log(teams[id] + ' lép '+point+'-at.');
		end = teamspos[id] + point;
		moving = setInterval(function(){
			if(teamspos[id] == end) clearInterval(moving);
			else {
				if(teamspos[id] >= 49) {
					teamspos[id] = 49;
					clearInterval(moving);
					alertBox('GRATULA!',' Nyert a '+teams[id]+' csapat!');
				}
				teamspos[id]++; 
				$('#cell-'+teamspos[id]).append($('#'+teams[id]));
				$('#mob-'+teams[id]).html(teamspos[id]);
			}
		},200);
	}
	function inf(i) {
		$('#info').append(', '+i);
	}
	function start() {
		curTeam = 0;
		index = 0;
		if(teams.length < 2) alertBox('<?php echo $lng['choose_at_least_two'];?>');
		else {
			for(var i=0; i<teams.length; i++) {
				$('#cell-0').append('<div id="'+teams[i]+'" class="'+teams[i]+' figure"></div>');
				$('#mobile-teams-box').append('<div class="mobile-team '+teams[i]+' figure"><span id="mob-'+teams[i]+'"class="mob-cnt">0</span></div>');
			}
			//$('#gameboard').css('background-color','rgb(from '+teams[0]+' r g b / 0.4);');
			$('#new-crd-btn').css('background-color',teams[0]);
			$('#start').hide();
			$('#gameboard').show();
		}
	}
	function rules() {
		$('#start').hide();
		$('#rules').show();
	}
	function round() {
		if(curTeam != teams.length-1) curTeam++;
		else curTeam=0;
		//$('#gameboard').css('background-color','rgb(from '+teams[0]+' r g b / 0.4);');
		$('#new-crd-btn').css('background-color',teams[curTeam])
		console.log('A következő csapat: ' + teams[curTeam] + ' - '+curTeam);
	}
	function getWord() {
		i = teamspos[curTeam];
		if(i <= 8 || (i>=25 && i<= 32)) { type = 'r'; }
		else if((i>=9 && i<= 16) || (i>=33 && i<= 40)) { type = 'k'; }
		else if((i>=17 && i<= 24) || (i>=41 && i<= 48)) { type = 'm'; }
		$.ajax({url: "getword.php",
				type: "POST",
				data: {type: type, ids: ids, lang: lang},
				dataType: "html"
			}).done(function (resp) {
				//alert(resp);
				//*
				r = JSON.parse(resp);
				//alert(r.word);
				$('#word').html(r.word +' ('+r.point+')');
				point = r.point*1;
				$('#goBut').show();
				ids += ','+r.id;
				console.log('Új Szó: '+r.word+' Típus: '+r.type+' Pont: '+r.point);
				/**/
			});
		$('#cardLayer').show();
	}

</script>