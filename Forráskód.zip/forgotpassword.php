<div id="center">
	<a href="./"><div id="logo"></div></a>
	<div class="box">
		<h1>Elfelejtett jelszó</h1>
		<form action="userAuth.php?forgot-password" method="post">
			<input class="input" type="text" name="email" id="email" placeholder="E-mail cím">
			<input class="primary-button" type="submit" value="E-mail küldése">
		</form>
	</div>
</div>