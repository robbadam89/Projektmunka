<?php
    include_once 'config.php';
    $r = 'rkm';
    $r = $r[rand(0, strlen($r)-1)];
    $type = isset($_POST["type"]) ? $_POST["type"] : $r; 
    $ids = isset($_POST["ids"]) ? $_POST["ids"] : '0';
    $q = "SELECT * FROM words_hu WHERE type = '$type' AND id NOT IN ($ids) AND deleted = 0 ORDER BY RAND() LIMIT 1";
    //echo $q;
    $result = $mysqli->query($q);
    $d = $result->fetch_array(MYSQLI_ASSOC);
    echo json_encode($d);
?>