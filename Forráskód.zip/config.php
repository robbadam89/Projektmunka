<?php
	session_start();
	$mysqli = new mysqli("localhost","root","","activity");
	$mysqli -> set_charset("utf8");
	
	if ($mysqli -> connect_errno) {
	  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
	  exit();
	}

	$lang = 'hu';

	//echo $lang;

	include_once 'langs/'.$lang.'.php';

	function logged() {
		if(isset($_SESSION['login'])) {
			return true;
		} else return false;
	}
?>