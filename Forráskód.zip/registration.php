<div id="center">
	<a href="./"><div id="logo"></div></a>
	<div class="box">
		<h1>Regisztráció</h1>
		<form action="userAuth.php?reg" method="post">
			<input class="input" type="text" name="username" id="regUsername" placeholder="Felhasználónév">
			<input class="input" type="text" name="email" id="regEmail" placeholder="E-mail cím">
			<input class="input" type="password" name="password" id="regPassword" placeholder="Jelszó">
			<input class="input" type="password" name="password2" id="regPassword2" placeholder="Jelszó mégegyszer">
			<input class="primary-button" type="submit" value="Regisztráció">
		</form>
	</div>
</div>