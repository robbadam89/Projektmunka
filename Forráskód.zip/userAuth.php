<?php
	ob_start();
	include_once "config.php";

	$_SESSION['msg'] = "";
	// bejelentkezes 
	if (isset($_GET['login'])) {
	    $username = trim($_POST['username'] ?? '');
	    $password = trim($_POST['password'] ?? '');

	    if ($username === '' || $password === '') {
	        $_SESSION['msg'] = "Hiányzó adat!";
	        exit;
	    }

	    // Prepared statement létrehozása
	    $stmt = $mysqli->prepare("SELECT id, password FROM users WHERE username = ? OR email = ? LIMIT 1");
	    $stmt->bind_param("ss", $username, $username);
	    $stmt->execute();
	    $result = $stmt->get_result();
	    $user = $result->fetch_assoc();

	    if ($user && password_verify($password, $user['password'])) {
	        // Sikeres bejelentkezés
	        $_SESSION['login'] = $user['id'];
	        $_SESSION['msg'] =  "Sikeres bejelentkezés!";
	        echo $_SESSION['login'];
	    } else {
	        $_SESSION['msg'] =  "Hibás felhasználónév vagy jelszó!";
	    }

	    $stmt->close();
	}

	//regisztráció
	if (isset($_GET['reg'])) {
	    $username = trim($_POST['username'] ?? '');
	    $email = trim($_POST['email'] ?? '');
	    $password = trim($_POST['password'] ?? '');
	    $password2 = trim($_POST['password2'] ?? ''); // jelszó megerősítés

	    // Alap ellenőrzések
	    if ($username === '' || $email === '' || $password === '') {
	        $_SESSION['msg'] =  "Hiányzó adat!";
	        exit;
	    }

	    if ($password !== $password2) {
	        $_SESSION['msg'] =  "A jelszavak nem egyeznek!";
	        exit;
	    }

	    // Ellenőrizzük, hogy létezik-e már a felhasználó vagy email
	    $stmt = $mysqli->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
	    $stmt->bind_param("ss", $username, $email);
	    $stmt->execute();
	    $result = $stmt->get_result();

	    if ($result->num_rows > 0) {
	        $_SESSION['msg'] =  "Felhasználónév vagy email már foglalt!";
	        exit;
	    }

	    // Hash-eljük a jelszót
	    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

	    // Mentés az adatbázisba
	    $stmt = $mysqli->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
	    $stmt->bind_param("sss", $username, $email, $hashedPassword);
	    if ($stmt->execute()) {
	        $_SESSION['msg'] =  "Sikeres regisztráció!";
	        // Automatikus login (opcionális)
	        $_SESSION['login'] = $mysqli->insert_id;
	    } else {
	        $_SESSION['msg'] =  "Hiba történt a regisztráció során.";
	    }

	    $stmt->close();
	}

	//kijelentkezes

	if(isset($_GET['logout'])){
	 session_destroy();
	}

	if (isset($_GET['new-password'])) {
	    $newPass   = trim($_POST['new-password'] ?? '');
	    $newPass2  = trim($_POST['new-password2'] ?? '');
	    $resetCode = trim($_POST['reset-code'] ?? ''); // elfelejtett jelszóhoz

	    if ($newPass === '' || $newPass2 === '') {
	        $_SESSION['msg'] = "Hiányzó adat!";
	        exit;
	    }

	    if ($newPass !== $newPass2) {
	        $_SESSION['msg'] = "Az új jelszavak nem egyeznek!";
	        exit;
	    }

	    // Új jelszó hash
	    $newHash = password_hash($newPass, PASSWORD_DEFAULT);

	    if ($resetCode !== '') {
	        // Elfelejtett jelszó - reset kód alapján
	        $stmt = $mysqli->prepare("SELECT id FROM users WHERE temp_code = ? LIMIT 1");
	        $stmt->bind_param("s", $resetCode);
	        $stmt->execute();
	        $result = $stmt->get_result();
	        $user   = $result->fetch_assoc();
	        $stmt->close();

	        if (!$user) {
	            $_SESSION['msg'] = "Érvénytelen vagy lejárt kód!";
	            exit;
	        }

	        $userId = $user['id'];

	        // Jelszó frissítése és reset_code törlése
	        $stmt = $mysqli->prepare("UPDATE users SET password = ?, reset_code = NULL WHERE id = ?");
	        $stmt->bind_param("si", $newHash, $userId);

	        if ($stmt->execute()) {
	            $_SESSION['msg'] = "Jelszó sikeresen megváltoztatva (reset kód alapján)!";
	        } else {
	            $_SESSION['msg'] = "Hiba történt a jelszó frissítése során.";
	        }
	        $stmt->close();

	    } else {
	        // Normál jelszóváltás - bejelentkezett user
	        if (!isset($_SESSION['login'])) {
	            $_SESSION['msg'] = "Nincs bejelentkezve!";
	            exit;
	        }

	        $userId = $_SESSION['login'];

	        $stmt = $mysqli->prepare("UPDATE users SET password = ? WHERE id = ?");
	        $stmt->bind_param("si", $newHash, $userId);

	        if ($stmt->execute()) {
	            $_SESSION['msg'] = "Jelszó sikeresen megváltoztatva!";
	        } else {
	            $_SESSION['msg'] = "Hiba történt a jelszó frissítése során.";
	        }
	        $stmt->close();
	    }
		    
	}
	if (isset($_GET['forgot-password'])) {
	    $email = trim($_POST['email'] ?? '');

	    if (empty($email)) {
	        $_SESSION['msg'] = "Kérjük, adja meg az e-mail címet!";
	    } else {
	        // Keresés adatbázisban
	        $stmt = $mysqli->prepare("SELECT id FROM users WHERE email = ?");
	        $stmt->bind_param("s", $email);
	        $stmt->execute();
	        $res = $stmt->get_result();

	        if ($res->num_rows === 0) {
	            $_SESSION['msg'] = "Ehhez az e-mail címhez nem tartozik felhasználó!";
	        } else {
	            // 32 karakteres kód generálása
	            $reset_code = bin2hex(random_bytes(16));

	            // Kód mentése az adatbázisba
	            $stmt_upd = $mysqli->prepare("UPDATE users SET reset_code = ? WHERE email = ?");
	            $stmt_upd->bind_param("ss", $reset_code, $email);
	            $stmt_upd->execute();

	            // E-mail küldés
	            $to = $email;
	            $subject = "Jelszó helyreállítás";
	            $message = "Kedves felhasználó,\n\nA jelszó helyreállításához használd a következő kódot:\n\n" . $reset_code . "\n\nHa nem te kérted, hagyd figyelmen kívül ezt az üzenetet.";
	            $headers = "From: no-reply@domain.tld\r\n";

	            //echo $message;

	            if (mail($to, $subject, $message, $headers)) {
	                $_SESSION['msg'] = "A helyreállító e-mailt elküldtük!";
	            } else {
	                $_SESSION['msg'] = "Hiba történt az e-mail küldése közben.";
	            }
	        }
	    }
	}

	header("Location: ./");

	ob_end_flush();
?>