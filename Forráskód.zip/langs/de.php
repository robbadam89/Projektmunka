<?php
	$lng = array(
	"lang_code"         		=> "DE-DE",
	"choose_team"         		=> "Wähle eine Farbe für dein Team:",
	"choose_at_least_two" 		=> "Wählen Sie mindestens zwei Teams aus!",
	"start_game"         		=> "Spiel beginnen",
	"add_new_word"         		=> "Neu hinzufügen",
	"new_card"         		    => "Neu Karte",
	"go"	         		    => "Start",
	"show_hide"	         		=> "Show",
	"fail"	         		    => "Absturz",
	"word"	         		    => "Wort",
	"pantomime"        		    => "Pantomimisch",
	"speak"	         		    => "Umschreibend",
	"draw"	         		    => "Zeichnen",
	"add"	         		    => "Hinzufügen",
	"back"	         		    => "Zurück",
	"added"	         		    => "Word zur Datenbank hinzugefügt. Dank!",
	"sum_words"	         		=> "Anzahl der Wörter in der Datenbank: ",
	"sum_words_draw"       		=> " in der Zeichnungskategorie",
	"sum_words_speak"	       	=> " in der Kreiskategorie",
	"sum_words_pantomime"      	=> " in der Show-Kategorie",
	"last_ten"	         		=> "Letzte 10 Wörter hinzugefügt",
	"random"	         		=> "RANDOM",
	"new_word"	         		=> "Neu wort",
	"easy"	         			=> "leicht",
	"medium"	         		=> "mittel",
	"hard"	         			=> "hart",
	"6pointer"	         		=> "Jeder kann raten",
	"timesup"	         		=> "Die Zeit ist abgelaufen!",
	/////////////////////
	"x" 						=> "x"
	);
?>