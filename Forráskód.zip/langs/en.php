<?php
	$lng = array(
	"lang_code"         		=> "EN-GB",
	"choose_team"         		=> "Pick your teams:",
	"choose_at_least_two" 		=> "Pick at least two teams!",
	"start_game"         		=> "Start Game",
	"add_new_word"         		=> "Add new word",
	"new_card"         		    => "New card",
	"go"	         		    => "Start",
	"show_hide"	         		=> "Show",
	"fail"	         		    => "FAil",
	"word"	         		    => "Word",
	"pantomime"        		    => "Pantomime",
	"speak"	         		    => "Speak",
	"draw"	         		    => "Draw",
	"add"	         		    => "Add",
	"back"	         		    => "Back",
	"added"	         		    => " has been added to the database! Thanks!",
	"random"	         		=> "RANDOM",
	"new_word"	         		=> "New word",
	"easy"	         			=> "Easy",
	"medium"	         		=> "Medium",
	"hard"	         			=> "Hard",
	"6pointer"	         		=> "6 pointer",
	"timesup"	         		=> "Time is up!",
	"rules"	         		    => "Rules",
	/////////////////////
	"x" 						=> "x"
	);
?>