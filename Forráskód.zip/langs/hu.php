<?php
	$lng = array(
	"lang_code"         		=> "HU-HU",
	"choose_team"         		=> "Válassz színt a csapatodnak:",
	"choose_at_least_two" 		=> "Válassz legalább két csapatot!",
	"start_game"         		=> "Játék indítása",
	"add_new_word"         		=> "Új szó hozzáadása",
	"new_card"         		    => "Új kártya",
	"go"	         		    => "MEHET",
	"show_hide"	         		=> "Mutat",
	"fail"	         		    => "Bukó",
	"word"	         		    => "Szó",
	"pantomime"        		    => "Mutogatás",
	"speak"	         		    => "Körülírás",
	"draw"	         		    => "Rajz",
	"add"	         		    => "Hozzáad",
	"back"	         		    => "Vissza",
	"added"	         		    => " szó hozzáadva az adatbázishoz. Köszi!",
	"random"	         		=> "VÉLETLENSZERŰ",
	"new_word"	         		=> "Új szó",
	"easy"	         			=> "könnyű",
	"medium"	         		=> "közepes",
	"hard"	         			=> "nehéz",
	"6pointer"	         		=> "mindenki kitalálhatja",
	"timesup"	         		=> "Lejárt az idő!",
	"rules"	         		    => "Szabályok",
	/////////////////////
	"x" 						=> "x"
	);
?>