<div id="center">
	<a href="./"><div id="logo"></div></a>
	<div class="full-box">
		<h1>Szabályok</h1>
		<span class="rules-text">
			A játékot legalább két csapattal lehet játszani, csapatonként két játékossal. Egy csapat egy figurát választhat magának. A játék célja hogy az adott feladványt az aktuális játékmezőnek megfelelően a csapat egyik tagja lerajzolja, elmutogossa vagy körülírja úgy hogy annak csapattársa azt könnyedén kitalálhassa. Egy-egy feladványra 90 másodperc van. A kitalált megfejtést a játék az adott szó meletti ponttal jutalmazza és annak alapján haladunk a játékmezőn. Ha egy szó 6 pontot ér akkor bármely csapat kitalálhatja a megfejtést, igy megnyerve annak lépéslehetőségét. Az nyer akinek a bábuja előbb célba ér.
		</span>
		<table>
			<tr><td><img src="images/r.png" alt="Rajz mező"></td><td><b>Rajzolás</b><br>Le kell rajzolni az adott feladványt. Betűk és számok nem használhatóak.</td></tr>
			<tr><td><img src="images/k.png" alt="Körülírás mező"></td><td><b>Körülírás</b><br>A feladvány szavának kiejtése nélkül kell kürölírni az adott fogalmat.</td></tr>
			<tr><td><img src="images/m.png" alt="Mutogatás mező"></td><td><b>Mutogatás</b><br>El kell mutogatni a feladványban található fogalmat anélkül, hogy környezetünkből bármit is felhasználnánk.</td></tr>
		</table>
	</div>
</div>