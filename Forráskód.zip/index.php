<?php
	include_once 'config.php';
	$logged = logged();
?>
<!DOCTYPE HTML>
<html lang="<?php echo $lng['lang_code'];?>">
<head>
	<meta charset="UTF-8">
	<title>Activity WEBition</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="style.css?<?php echo time();?>" />
	<style type="text/css">
	</style>
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>
	
	<?php
		if(isset($_SESSION['msg']) && $_SESSION['msg'] != "") 
			echo '<div id="msg-box"><strong>'.$_SESSION['msg'].'</strong></div>';

		if(isset($_GET['p'])) {
			$p = $_GET['p'];
		} else $p = 'game';
		include_once $p .'.php';

		$_SESSION['msg'] = "";

	?>
	<div id="alertBox" display="none">
		<h1 id="alertBoxHeader"></h1>
		<h3 id="alertBoxContent"></h3>
		<button class="secondary-button">OK</button>
	</div>
	<div id="user">
		<div class="box">
<?php
	if($logged) {
?>
	<ul>
		<li><a class="button" href="./">Új játék</a></li>
		<li><a class="button" href="?p=addword">Új szó hozzáadása</a></li>
		<li><a class="button" href="?p=settings">Beállitások</a></li>
		<li><a class="button" href="userAuth.php?logout">Kijelentkezés</a></li>
	</ul>
<?php
	} else {		
?>	
	<h1>Menü</h1>
	<ul>
		<li><a class="primary-button" href="./">Új játék</a></li>
		<li><a class="primary-button" href="?p=registration">Regisztráció</a></li>
	</ul>
	<br/>
	<h2>Bejelentkezés</h2>
	<form action="userAuth.php?login" method="post">
		<input class="input" type="text" name="username" id="loginun" placeholder="Felhasználónév vagy e-mail">
		<input class="input" type="password" name="password" id="loginpw" placeholder="Jelszó">
		<input class="primary-button" type="submit" value="Bejelentkezés">
	</form>
	<a href="?p=forgotpassword">Elfelejtett jelszó</a></li>
<?php
	}
?>
		</div>
	</div>
	<div id="accountBox">
		<input id="accountBut" class="" type="button" value="Menü">
	</div>
	<script>
		$(document).ready(function() {
			$('#accountBut').click(function(){
				$('#user').toggle();
			});
			setTimeout(function() { 
		        $('#msg-box').fadeOut();
		    }, 2000);
		});
		function alertBox(header,content) {
			$('#alertBoxHeader').html(header);
			$('#alertBoxContent').html(content);
			$('#alertBox').show();
			$('#alertBox').on('click',function () {$('#alertBox').hide()});
		}
	</script>
</body>
</html>